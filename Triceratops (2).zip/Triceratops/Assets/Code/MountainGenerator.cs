﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MountainGenerator : MonoBehaviour
{
    public GameObject theMountains;
    public Transform generationPoint;
    public float distanceBetween;

    private float mountainWidth;
    // Start is called before the first frame update
    void Start()
    {
        mountainWidth = theMountains.GetComponent<SpriteRenderer>().size.x;
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.x < generationPoint.position.x)
        {
            transform.position = new Vector3(transform.position.x + mountainWidth + distanceBetween, transform.position.y, transform.position.z);
            Instantiate(theMountains, transform.position, transform.rotation);
        }
    }
}
