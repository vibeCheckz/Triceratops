﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlCharacter : MonoBehaviour
{
    public Animator animator;
    float speed = 1.5f;
    float speedJ = 2.0f;
    float moveSpeed = 5f;
    public bool isGrounded = false;
    // Start is called before the first frame update
    void Start()
    {
        //animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        Jump();
        Vector3 movement = new Vector3(Input.GetAxis("Horizontal"), 0f, 0f);
        transform.position += movement * Time.deltaTime * moveSpeed;
        MoveCharacter();
    }

    void MoveCharacter()
    {
        /*transform.Translate(Vector3.right * speed * Time.deltaTime);
        if(Input.GetKey(KeyCode.Space))
        {
           // animator.SetBool("jump", true);
            transform.Translate(Vector3.up * speedJ * Time.deltaTime);
        }
        else
        {
           // animator.SetBool("jump", false);
        }*/
    }

    void Jump()
    {
        if (Input.GetButtonDown("Jump"))
        {
            gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(0f, 5f), ForceMode2D.Impulse);
        }
    }

}
